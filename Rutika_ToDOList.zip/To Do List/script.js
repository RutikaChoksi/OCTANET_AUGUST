
const getForm = document.getElementById('form');
let todoTopic = document.getElementById('input');
let todoTopicItems = document.getElementById('todos-list')
const sorts = document.getElementById('SortBtn');
const clearAllBtn = document.getElementById('clearAllBtn');


let todoList = JSON.parse(localStorage.getItem('todoList')) || []
// todoList.push({ value: "", checkStatus: false });

viewTodo();
 

getForm.addEventListener('submit', function (event) {
    event.preventDefault();
    // console.log('Entered')
    addTodo();
    viewTodo();
    localStorage.setItem('todoList',JSON.stringify(todoList));
})


function addTodo() {
    const todoValue = todoTopic.value.trim().replace(/\s+/g, ' ');
    if (todoValue === "") {
        alert("Task Cannot Be Empty!!!");
        return;
    } else if (todoList.some(todo => todo.value.trim().toLowerCase() === todoValue.toLowerCase())) {
        alert("Task already Present");
        return;
    }
    
    const priorityValue = document.getElementById('priorityInput').value.toLowerCase() || 'low';
    if (!['high', 'medium', 'low'].includes(priorityValue)) {
        alert("Invalid Priority! Please use 'high', 'medium', or 'low'.");
        return;
    }
    
    const todoObj = {
        value: todoValue,
        checkStatus: false,
        priority: priorityValue
    };
    
    todoList.push(todoObj);
    console.log(todoList);
    todoTopic.value = "";
}



function viewTodo() {
    if(todoList.length === 0) {
        todoTopicItems.innerHTML = '<center>Nothing To Do Today</center>';
        return;
    }

    todoTopicItems.innerHTML = "";
    todoList.forEach((todo, index) => {
        const priorityClass = todo.priority === 'high' ? 'high-priority' :
                            todo.priority === 'medium' ? 'medium-priority' :
                            todo.priority === 'low' ? 'low-priority' : '';

        todoTopicItems.innerHTML +=
            `
        <div class="todo ${priorityClass}" id=${index}>
          <i class="bi ${todo.checkStatus ? 'bi-check-circle-fill': 'bi-circle'}" data-perform="check"></i>
          <p class="${todo.checkStatus ? 'checked-text' : '' } ${priorityClass}" data-perform="edit" contenteditable="true">${todo.value}</p>
          <i class="bi bi-trash" data-perform="delete"></i>
        </div>
        `;
    });

    const editElements = document.querySelectorAll('[data-perform="edit"]');
    editElements.forEach((element, index) => {
        element.addEventListener('blur', () => {
            editTodo(index, element.textContent);
        });

        element.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault();
                element.blur();
                editTodo(index, element.textContent);
            }
        });
    });
}


todoTopicItems.addEventListener('click', (event) => {
    const target = event.target;        
    const parentElement = target.parentNode;

    if (!parentElement.classList.contains('todo')) return;
    const todo = parentElement;
    const todoId = Number(todo.id);

    const perform = target.dataset.perform;
  
    if (perform === "check") checkTodo(todoId);
    if (perform === "edit") editTodo(todoId);
    if (perform === "delete") deleteTodo(todoId);

    console.log(todoId, perform);
});



function editTodo(index, newValue) {
    if (index >= 0 && index < todoList.length) {
        const trimmedNewValue = newValue;
        if (trimmedNewValue === "") {
            alert("Task Cannot Be Empty!!!");
            viewTodo();
            localStorage.setItem('todoList', JSON.stringify(todoList));
            return;
        } else if (todoList.some((todo, i) => i !== index && todo.value.toLowerCase() === trimmedNewValue.toLowerCase())) {
            alert("Edited Task Already Exists!!!");
            viewTodo();
            localStorage.setItem('todoList', JSON.stringify(todoList));
            return;
        }
        
        todoList[index].value = trimmedNewValue;
        viewTodo();
        localStorage.setItem('todoList', JSON.stringify(todoList));
    }
}


function checkTodo(todoId) {
    todoList = todoList.map((todo, index) => {
        return {
            value: todo.value,
            checkStatus: index === todoId ? !todo.checkStatus : todo.checkStatus,
            priority: todo.priority
        };
    });

    viewTodo();
    localStorage.setItem('todoList', JSON.stringify(todoList));
    console.log(todoList);
}

function deleteTodo(todoId) {
    todoList = todoList.filter((todo, index) => index !== todoId);
    viewTodo();
    localStorage.setItem('todoList', JSON.stringify(todoList));
    console.log(todoList);
}

clearAllBtn.addEventListener('click', clearAll);
function clearAll() {
    if (confirm("Are you sure") == true) {
        todoList = []; 
        console.log(todoList)
        viewTodo();
        localStorage.setItem('todoList',JSON.stringify(todoList));

}
}


sorts.addEventListener('click', sort);
function sort() {
    todoList.sort((a, b) => {
        if (a.checkStatus && !b.checkStatus) {
            return 1;
        }
        if (!a.checkStatus && b.checkStatus) {
            return -1; 
        }
    });

    viewTodo();
    localStorage.setItem('todoList', JSON.stringify(todoList));
}
